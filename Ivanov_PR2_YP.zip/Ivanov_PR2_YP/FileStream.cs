﻿namespace Wpf_Ivanov_PR2_YP
{
    internal class FileStream
    {
    }
}